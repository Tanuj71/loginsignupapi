package com.qreceiptoproject.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Qproject1Application {

	public static void main(String[] args) {
		SpringApplication.run(Qproject1Application.class, args);
	}

}
