package com.qreceiptoproject.app.payload;



import lombok.Data;

@Data
public class SignUpDto {
	

	
	    private String firstName;
	    
	   
	    private String lastName;
	    
	    private long phoneNumber;
	    
	    private String date;
	    
	    private String genderName;
	    
	    private String countryName;
	    
	    private String username;
	    
	    private String email;
	    
	    private String password;
	    
	    private String confirmpassword;
	    }